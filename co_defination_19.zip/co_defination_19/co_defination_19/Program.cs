﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace co_defination_19
{
    class Program
    {
        class Car
        {
            public string model;
            public Car() //Constructor
            {
                model = "Nano";
            }
            static void Main(string[] args)
            {
                Car Ford = new Car();
                Console.WriteLine(Ford.model);
                Console.Read();
            }
        }
    }
}