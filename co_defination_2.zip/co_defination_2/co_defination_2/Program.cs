﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace co_defination_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Name    : Sarvaiya Neha j.");
            Console.WriteLine("course  : BCA");
            Console.WriteLine("sem     : 4");
            Console.WriteLine("collage : Geetanjali collage");
            Console.Read(); 
        }
    }
}
