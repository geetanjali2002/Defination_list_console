﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace co_defination_7
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;

            Console.Write("Enter Any Number Between 1 to 7 : ");
            a = Convert.ToInt32(Console.ReadLine());

            switch (a)
            {
                case 1:
                    Console.Write("Sunday");
                    break;
                case 2:
                    Console.Write("Monday");
                    break;
                case 3:
                    Console.Write("Tuesday");
                    break;
                case 4:
                    Console.Write("Wednesday");
                    break;
                case 5:
                    Console.Write("Thursday");
                    break;
                case 6:
                    Console.Write("Friday");
                    break;
                case 7:
                    Console.Write("Saturday");
                    break;
                default:
                    Console.Write("Invalid Number");
                    break;
            }

            Console.Read();
        }
    }
}
