﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace co_defination_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int m1,m2,m3, total;
            string grade, result;
            double per;

            Console.Write("Enter Marks Form m1 : ");
            m1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Marks For m2 : ");
            m2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Marks For m3 : ");
            m3 = Convert.ToInt32(Console.ReadLine());

            total = m1 + m2 + m3;

            if (m1 >= 40 && m2 >= 40 && m3 >= 40 )
            {
                result = "PASS";
                per = total / 4;
                if (per >= 70)
                {
                    grade = "Dist.";
                }
                else if (per >= 60)
                {
                    grade = "First";
                }
                else if (per >= 50)
                {
                    grade = "Second";
                }
                else
                {
                    grade = "PASS";
                }
            }
            else
            {
                result = "FAIL";
                grade = "-";
                per = 0.0;
            }

            Console.WriteLine("Your Total is :" + total);
            Console.WriteLine("Your Percentage is : " + per);
            Console.WriteLine("Your Grade is : " + grade);
            Console.WriteLine("Your Result is : " + result);
            Console.ReadKey();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
        }
    }
}
