﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace co_defination_18
{
    class a
    {
        public int m1 = 28;
        public void result()
        {
            Console.WriteLine("FAIl");
        }
    }

    class b : a
    {
        public int m2 = 26;
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            b bb = new b();
            bb.result();

            Console.WriteLine(bb.m1 + " " + bb.m2);
            Console.Read();
        }
    }
}