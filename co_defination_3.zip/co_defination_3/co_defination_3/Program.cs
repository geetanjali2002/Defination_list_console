﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace co_defination_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c;
            Console.WriteLine("Input number a & b");
            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());

            c = a + b;
            Console.WriteLine("Addition is= " + c);

            c = a - b;
            Console.WriteLine("Subtration is=" + c);

            c = a * b;
            Console.WriteLine("multiplication is= " + c);

            c = a / b;
            Console.WriteLine("Division is= " + c);

            c = a % b;
            Console.WriteLine("Module is=" + c);

            Console.Read();
        }
    }
}
