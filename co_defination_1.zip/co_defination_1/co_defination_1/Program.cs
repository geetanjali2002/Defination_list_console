﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace co_defination_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("welcome to collage....");
            Console.Read();
        }
    }
}
