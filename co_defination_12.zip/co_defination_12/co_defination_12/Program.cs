﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace co_defination_12
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int[,] arr = {{11,12,13,14},
                          {21,22,23,24},
                          {31,32,33,34}};
            
            foreach (int i in arr)
            {
                Console.Write(i + " ");
            }

            Console.WriteLine("\n");            
            for (int i = 0; i < arr.GetLength(0); i++)
            {
                for (int j = 0; j < arr.GetLength(1); j++)
                {
                    Console.Write(arr[i, j] + " ");
                }
            }
            Console.ReadKey();
        }
    }
}
