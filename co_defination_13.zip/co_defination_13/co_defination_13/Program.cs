﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace co_defination_13
{
    class Program
    {
        public static void welcome(string name)
        {
            Console.WriteLine("Welcome " + name);
        }
        public static void HaveAnice()
        {
            Console.WriteLine("Have a nice day");
        }
        static void Main(string[] args)
        {
            string str1;
            Console.Write("Please Enter a name : ");
            str1 = Console.ReadLine();
            welcome(str1);
            HaveAnice();

            Console.ReadLine();
        }
    }
}
