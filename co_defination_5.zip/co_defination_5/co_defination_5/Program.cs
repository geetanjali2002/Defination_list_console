﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace co_defination_5
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            Console.Write("Enter a number:");
            num = Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("{0}*{1}={2}", num, i, num * i);
            }
            Console.ReadKey();
        }
    }
}
